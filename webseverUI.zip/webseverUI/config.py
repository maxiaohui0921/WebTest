#选择broswer
browserType="Chrome"
chromeWebDriverPath=r"C:\Program Files (x86)\Google\Chrome\Application\chromedriver.exe"
# browserType="FireFox"
fireFoxWebDriverPath=r"D:\install\python36\Scripts\geckodriver.exe"

#webserver登录地址
url="http://192.168.27.7:8080"

#人员图片地址
imagePath=r"D:\03.data\data\20人照片"


