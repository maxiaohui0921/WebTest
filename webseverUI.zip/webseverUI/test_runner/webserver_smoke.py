from test_device.webserver import Webserver
import os,unittest,time,HTMLTestRunner,random
import common

class SmokeTest(unittest.TestCase):
    ws=Webserver()

    @classmethod
    def setUpClass(cls):
        cls.ws.login("2580")

    @classmethod
    def tearDownClass(cls):
        cls.ws.logout()
        cls.ws.exitBrowser()

    def test_01_addPerson(self):
        self.ws.addPerson(common.generName(),common.generId(),common.generId(),"34837","icsd")

    def test_02_adjustVolume(self):
        v=random.choice(range(1, 15))
        print("调节音量：%s"%v)
        self.ws.adjustVolume(v)

if __name__=="__main__":
    report_time = time.strftime("%Y%m%d%H%M%S", time.localtime())  # 文件名称
    file_name = os.path.dirname(os.path.abspath('.')) + '\\test_result\\WebServerUI_' + report_time + "_result.html"  # 文件存放地址
    print(file_name)
    fp = open(file_name, 'wb')
    print(file_name)
    suite = unittest.makeSuite(SmokeTest, prefix='test')
    runner = HTMLTestRunner.HTMLTestRunner(stream=fp, title=u'WebServerUI测试报告', description=u'用例执行情况：')
    runner.run(suite)
    fp.close()