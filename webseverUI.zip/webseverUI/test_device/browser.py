from selenium import webdriver
import time,random,config

class Browser(object):

    def __init__(self):
        if config.browserType=="Chrome":
            self.driver = webdriver.Chrome(config.chromeWebDriverPath)
        elif config.browserType=='FireFox':
            self.driver=webdriver.Firefox(config.fireFoxWebDriverPath)
        time.sleep(5)

    def clickByXPath(self,xpath,sleepTime=1):
        self.driver.find_element_by_xpath(xpath).click()
        time.sleep(sleepTime)

    def enterTxtByXPath(self,xpath,txt,sleepTime=1):
        self.driver.find_element_by_xpath(xpath).send_keys(txt)
        time.sleep(sleepTime)

    def enterTxtByClassWithIndex(self,className,indexN,txt,sleepT=1):
        self.driver.find_elements_by_class_name(className)[indexN].send_keys(txt)
        time.sleep(sleepT)

    def clickByClassWithIndex(self,className,indexN,sleepT=1):
        self.driver.find_elements_by_class_name(className)[indexN].click()
        time.sleep(sleepT)

    def clickByClass(self,className,sleepT=1):
        self.driver.find_element_by_class_name(className).click()
        time.sleep(sleepT)

    def getRandomOption(self,className,sleepTime=2):
        itemRandom=random.choice(range(len(self.driver.find_elements_by_class_name(className))))
        time.sleep(sleepTime)
        return itemRandom

    def exitBrowser(self):
        self.driver.close()

if __name__=="__main__":
    pass