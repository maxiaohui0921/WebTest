from test_device.browser import Browser
import time
import config,common

class Webserver(Browser):

    def login(self,pwd):
        self.driver.get(config.url)
        time.sleep(1)
        self.enterTxtByXPath('//*[@id="app"]/div[2]/div/section/form/div[1]/div/div/input',pwd,1)
        self.clickByXPath('//*[@id="app"]/div[2]/div/section/form/div[2]/div/button',1)

    def enterMoreMenu(self,menu,menuSub=""):
        self.clickByXPath('//*[@id="app"]/div[1]/div/div[2]',1)
        el_submenu = {0: ["设备设置", "管理员", "配置管理"], 1: ["通行记录"]}
        if menuSub:
            for i in el_submenu:
                if menuSub in el_submenu[i]:
                    break
            self.clickByClassWithIndex('el-submenu',i)
            time.sleep(1)
            self.driver.find_element_by_link_text(menuSub).click()
        else:
            self.driver.find_element_by_link_text(menu).click()
        time.sleep(1)

    def addPerson(self,name,personId,idCard="",icCard="",doorCard=""):
        self.enterMoreMenu("人员管理")
        self.clickByXPath('//*[@id="app"]/div[2]/div/section[2]/ul/li[1]/a/button/span',1) #添加人员
        self.driver.find_element_by_name('file').send_keys(common.randomChoiceFile(config.imagePath))
        time.sleep(3)
        self.enterTxtByClassWithIndex("el-input__inner",0,name)
        self.enterTxtByClassWithIndex("el-input__inner",1,personId)
        self.enterTxtByClassWithIndex("el-input__inner", 2, idCard)
        self.enterTxtByClassWithIndex("el-input__inner", 3, icCard)
        self.enterTxtByClassWithIndex("el-input__inner", 4, doorCard)
        #选择人员规则
        self.clickByClassWithIndex('select-field',0)
        # randomItem = self.getRandomOption('el-radio')
        self.clickByClassWithIndex('el-radio',1)
        # 点击确定
        self.clickByXPath('/html/body/div/div[2]/div/div[2]/form/div[7]/div/div/div/div[2]/div/div[3]/button[2]', 1)

        #选择人员库
        # self.clickByClassWithIndex('select-field',1,2)
        # randomItem = self.getRandomOption('el-radio')
        # self.clickByClassWithIndex('el-radio', 0)
        # 点击确定
        # self.clickByXPath('/html/body/div/div[2]/div/div[2]/form/div[8]/div/div/div/div[2]/div/div[3]/button[2]', 1)
        # 点击保存
        self.driver.find_element_by_class_name('el-button').click()  #经验，找不到定位就用class定位
        time.sleep(3)

    def adjustVolume(self,volumn):
        volumn=str(volumn)
        self.enterMoreMenu("设备管理","设备设置")
        self.driver.find_element_by_link_text("通用设置").click()
        #获取当前音量
        volumn1 = self.driver.find_element_by_class_name('el-input__inner').get_attribute("aria-valuenow")
        button1="el-input-number__decrease"
        button2='el-input-number__increase'
        while volumn!=volumn1:
            if int(volumn) >int(volumn1):
                self.clickByClass(button2)
            elif int(volumn)<int(volumn1):
                self.clickByClass(button1)
            volumn1 = self.driver.find_element_by_class_name('el-input__inner').get_attribute("aria-valuenow")
        self.clickByClass('el-button',1)
        time.sleep(3)

    def delAllPerson(self):
        self.enterMoreMenu("人员管理")
        self.clickByXPath('//*[@id="app"]/div[2]/div/section[1]/ul/li[1]/a',2)
        self.clickByXPath('/html/body/div[2]/div/div[3]/button[2]')
        time.sleep(3)

    def logout(self):
        self.enterMoreMenu("工作台")
        self.clickByClass('icon-log-out') #点击退出登录
        self.clickByXPath('/html/body/div[2]/div/div[3]/button[2]') #点击确定退出

if __name__=="__main__":
    w1=Webserver()
    # w1.addPerson("马晓惠","1232er32","133029190202020099","1232","321123")
    w1.login("2580")
    w1.adjustVolume(12)
    # w1.delAllPerson()
    # w1.logout()