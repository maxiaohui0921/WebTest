import random,os
from datetime import date, timedelta

#任意选一个文件，返回文件全目录
def randomChoiceFile(path):  #
    list=os.listdir(path)
    f=path+"\\"+random.choice(list)
    return f

#自动生成人员编号
def generName():
    a1=['张','金','李','王','赵',"牛","马","何","南","令狐","孙","猪","唐","丛","钟","龙","蔡","范","白","曹"]
    a2=['玉','明','龙','芳','军','玲','小',"士","司","冲","悟","亿","白","华","哥","下","美","贵","锄","禾","日","当","午"]
    a3=['轩','立','玲','子','国','',"节","奇","离","旋","一","七","会","朋","友","汪", "喵", "嘶", "嘘", "哈", "嘻", "滴", "弩", "花", "会", "好"]
    a4=["","","","","午","","滴","禾","","土",""]
    name=random.choice(a1)+random.choice(a2)+random.choice(a3)+random.choice(a4)
    return name

#随机生成身份证号
def generId():
    id = "131020"
    id = id + str(random.randint(1900, 2016))  # 年份项
    da = date.today() + timedelta(days=random.randint(1, 366))  # 月份和日期项
    id = id + da.strftime('%m%d')
    id = id + str(random.randint(100, 300))  # ，顺序号简单处理
    count = 0
    weight = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]  # 权重项
    checkcode = {'0': '1', '1': '0', '2': 'X', '3': '9', '4': '8', '5': '7', '6': '6', '7': '5', '8': '5', '9': '3','10': '2'}  # 校验码映射
    for i in range(0, len(id)):
        count = count + int(id[i]) * weight[i]
    id = id + checkcode[str(count % 11)]  # 算出校验码
    return id