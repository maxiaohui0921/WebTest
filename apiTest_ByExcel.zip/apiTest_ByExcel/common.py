#-*-coding:utf-8-*-
#__author__='maxiaohui'
import config
import time, urllib3,re,random,os
from datetime import date,timedelta
from win32com.client import Dispatch
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

#excel基本操作封装
class easyExcel:  # 用于excel处理

    def __init__(self, filename=None):  # 打开文件或者新建文件（如果不存在的话）
        self.xlApp = Dispatch('Excel.Application')
        self.xlApp.Visible = False
        if filename:
            self.filename = filename
            self.xlBook = self.xlApp.Workbooks.Open(filename)
        else:
            self.xlBook = self.xlApp.Workbooks.Add()
            self.filename = ''

    def addSheet(self, sheetname):  # 加入一个指定名称的sheet
        self.xlApp.Worksheets.Add().Name = sheetname
        xlSheet = self.xlApp.Worksheets(sheetname)
        return xlSheet

    def getSheet(self, sheetname):  # 根据名称获得某个sheet
        xlSheet = self.xlApp.Worksheets(sheetname)
        return xlSheet

    def removeFloat(self, v):  # 处理excel读出的数字变成了浮点类型
        if str(v).find(".0") >= 0:
            b = str(v)
            c = b.replace(".0", "")
        else:
            c = str(v)
        return c

    def writeCellwithBeforeValue(self, xlSheet, r, c, v):  # 写cell,处理原有item叠加
        vBefore = xlSheet.Cells(r, c).Value
        if vBefore == None:
            time.sleep(0.01)
            xlSheet.Cells(r, c).Value = v
        else:
            time.sleep(0.005)
            vBefore = self.removeFloat(vBefore)
            xlSheet.Cells(r, c).Value = str(vBefore) + ';' + v

    def writeCell(self, xlSheet, r, c, v):  # 写cell
        # time.sleep(0.02)
        xlSheet.Cells(r, c).Value = v

    def getCell(self,xlSheet,r,c):
        return xlSheet.Cells(r,c).Value

    def writeRow(self, xlSheet, list, rowID, startColumn=1):  # 把列表写入指定行,可指定起始列
        for i in range(startColumn, startColumn + len(list)):
            self.writeCell(xlSheet, rowID, i, list[i - startColumn])

    def filterColumnTextContains(self, xlSheet, rowNumbers, columnNumber, filterChar):  # 筛选出某一列包含某字符串的条目的个数
        count = 0
        rowList=[]
        for i in range(2, rowNumbers + 1):
            if xlSheet.Cells(i, columnNumber).Value.find(filterChar) >= 0:
                count += 1
                rowList.append(i)
        return count,rowList

    def findTxtInColumn(self, sheet, column, startRow, endRow, txt):

        rowNum = 0
        for i in range(startRow, endRow + 1):
            time.sleep(0.3)
            if sheet.Cells(i, column).Value == txt:
                rowNum = i
                break
        return rowNum

    def get_cell_cols(self, sheet):  # 获得总得列数
        return sheet.UsedRange.Columns.Count

    def getRange(self,sht,row1,col1,row2,col2):  #获得某一个范围的值
        return sht.Range(sht.Cells(row1, col1), sht.Cells(row2, col2)).Value

    def save(self):
        self.xlBook.Save()

    def saveAs(self,file):
        self.xlBook.SaveAs(file)

    def closeFile(self):
        self.xlApp.Quit()

#从excel中获取测试用例数据，用各种方式筛选，返回不同数据
class caseGener(easyExcel):

    def __init__(self,filename=None):
        super(caseGener,self).__init__(filename)
        self.sheet=self.getSheet("testCase")

    #根据列生成单条case,字典类型
    def getTestCase(self,row): #获得相关case数据
        testId = self.sheet.Cells(row, 1).Value
        testModule = self.sheet.Cells(row, 2).Value
        testName = self.sheet.Cells(row, 3).Value
        testType = self.sheet.Cells(row, 4).Value
        testUrl = self.sheet.Cells(row, 5).Value
        testMethod = self.sheet.Cells(row, 6).Value
        testParaType = self.sheet.Cells(row, 7).Value
        testCookies = self.sheet.Cells(row, 8).Value
        testData = self.sheet.Cells(row, 9).Value
        testExecute = self.sheet.Cells(row, 10).Value
        testParaRefer = self.sheet.Cells(row, 11).Value
        testExpected = self.sheet.Cells(row, 16).Value  #断言参考
        dict = {'id': testId,'module': testModule, 'name': testName, 'type': testType,
                'url': testUrl, 'method': testMethod,'paraType':testParaType,'cookies':testCookies,
                'data':testData,'executeOrNot':testExecute,'referAPI':testParaRefer,"assertExpected":testExpected}
        return dict

    #根据列list，生成case列表
    def getTestCaseList(self,rowList):
        caseList=[]
        for i in rowList:
            caseList.append(self.getTestCase(i))
        return caseList

    #根据testId找到相应的row,获取到相应的case详情
    def getTestCaseById(self,testId,caseNum):
        # print("我被调用到了，我要找的caseId是%d"%testId)
        row = self.findTxtInColumn(self.sheet,1,2,caseNum+1,float(testId))
        return self.getTestCase(row)

    # 根据testId找到相应的row
    def getTestCaseRowById(self, testId, caseNum):
        # print("我被调用到了，我要找的caseId是%d"%testId)
        row = self.findTxtInColumn(self.sheet, 1, 2, caseNum + 1, float(testId))
        return row

    #根据条件筛选出caseId列表，
    def getApiTestCasesIdByFilter(self,rowNum,filterColumn,txt):
        count,rowList = self.filterColumnTextContains(self.sheet,rowNum,filterColumn,txt)
        return rowList

    #根据testId列,统计共有多少条case,testId必须非空
    def getCaseNumbersById(self):
        caseNum=0
        row=2
        while self.sheet.Cells(row,1).Value:
            caseNum+=1
            row+=1
        return caseNum

    #data参数化处理，获取业务依赖参数,并返回依赖函数id.
    #只有无法分析的data参数才需要这个函数去处理
    def getParaRefer(self,case):
        # url=case['url']
        data=case["data"]       #   '{"data":config.data}'
        referAPIlist = re.compile(r'(config\.\d+\.\S+)[},]').findall(data)  #['config.12.rule', 'config.12.uploadJpegPic']
        if referAPIlist:
            for i in range(len(referAPIlist)):
                referAPIlist[i]=referAPIlist[i].replace(")","")    #打补丁，为了补救正则表达式无法去除）的问题
        referCommon = re.compile(r'(common\.\S+\.\S+)[,}]').findall(data)
        referFile = re.compile(r'(file_\S+_\S+)[,]').findall(data)
        # urlReferAPIlist =re.compile(r'(config\.\d+\.\S+)').findall(url)
        return referAPIlist,referCommon,referFile   # 调用referAPIdic返回的值，去replace datalist里的字符串，产生正确的data

    def getUrlParaRefer(self,case):   #解析出url中的依赖列表
        url = case['url']
        urlReferAPIlist = re.compile(r'(config\.\d+\.\S+)').findall(url)
        return  urlReferAPIlist

#接口中随机调用的一些参数，随机生成一个人员信息
class people:

    def __init__(self):
        self.name=self.getName()
        self.no=self.getNo()
        self.idCard=self.getIdCard()
        self.wgNo=self.getWgNo()
        self.icNo=self.getICno()
        self.facePic=self.getFacePic()

    def getName(self):
        a1 = ['张', '金', '李', '王', '赵', "牛", "马", "何", "南", "令狐", "孙", "猪", "唐", "丛", "钟", "龙", "蔡", "范", "白", "曹"]
        a2 = ['玉', '明', '龙', '芳', '军', '玲', '小', "士", "司", "冲", "悟", "亿", "白", "华", "哥", "下", "美", "贵", "锄", "禾", "日",
              "当", "午"]
        a3 = ['轩', '立', '玲', '子', '国', '', "节", "奇", "离", "旋", "一", "七", "会", "朋", "友", "汪", "喵", "嘶", "嘘", "哈", "嘻",
              "滴", "弩", "花", "会", "好"]
        # a4 = ["", "", "", "", "午", "", "滴", "禾", "", "土", ""]
        name = random.choice(a1) + random.choice(a2) + random.choice(a3)
        return name

    def getNo(self):
        return random.choice([chr(i) for i in range(97, 123)])+str(random.choice(range(10000000,99999999)))

    def getIdCard(self):
        id = "131020"
        id = id + str(random.randint(1900, 2016))  # 年份项
        da = date.today() + timedelta(days=random.randint(1, 366))  # 月份和日期项
        id = id + da.strftime('%m%d')
        id = id + str(random.randint(100, 300))  # ，顺序号简单处理
        count = 0
        weight = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2]  # 权重项
        checkcode = {'0': '1', '1': '0', '2': 'X', '3': '9', '4': '8', '5': '7', '6': '6', '7': '5', '8': '5', '9': '3',
                     '10': '2'}  # 校验码映射
        for i in range(0, len(id)):
            count = count + int(id[i]) * weight[i]
        id = id + checkcode[str(count % 11)]  # 算出校验码
        return id

    def getWgNo(self):
        return str(random.choice(range(100000,999999)))

    def getICno(self):
        return self.getNo()

    def getFacePic(self):
        list = os.listdir(config.imageFolderPath)
        picPath = config.imageFolderPath + "\\" + random.choice(list)
        return picPath

#获取类对象的属性key value字典
def getClassAttributeKeyValueDict(cl):
    dic={}
    for name, value in vars(cl).items():
        dic[name]=value
    return dic

if __name__ == "__main__":

    # p1=people()
    # print(p1.facePic)

    caseG = caseGener(config.casePath)
    # print(caseG.getTestCaseById(7,15))
    # print(caseG.getTestCaseById(8,15))

    # caseList = caseG.getTestCaseList(range(2, 17))
    # for i in caseList:
    #     try:
    #         # data=json.loads(i['data'])
    #         # print(type(i['data']))
    #         # print(i['data'])
    #         print(type(i['referAPI']))
    #         print(i['referAPI'])
    #         time.sleep(1)
    #     except TypeError:
    #         print("没有参数")