import re,random,shutil,time
from requests import session
import config,common
from common import caseGener,people

#测试结果文件
report_time = time.strftime("%Y%m%d%H%M%S", time.localtime())  # 文件名称
resultFile = config.testResultPath + '\\APIbyExcel_' + report_time + "_result.xlsx"  # 文件存放地址
shutil.copyfile(config.casePath, resultFile)
time.sleep(5)
caseG = caseGener(resultFile)  #只生成一次，在整个执行过程中只有这一个对象
totalCaseNumber=caseG.getCaseNumbersById()  #所有的case对象caseG

#一个类实例代表一条api测试的用例
# 该类实例要runcase，依赖于外部的sesson。 所以：必须在这之前建立requests的session
class apiCase():

    classRefer = {"people": people()}

    def __init__(self,case):   #case是个字典，api传入参数是字符串
        self.id = case['id']
        self.module = case['module']
        self.name = case['name']
        self.type = case['type']
        self.url = case['url']
        self.method = case['method']
        self.paraType = case['paraType']
        self.cookies = case['cookies']
        self.data = case['data']
        self.executeStatus = case['executeOrNot']
        self.refer = case['referAPI']
        self.fileObj = []   #解决类内部的自己的file,如果依赖也需要文件
        self.assertExpected = case['assertExpected']

    #跑api测试，所有数据已经ready
    def runAPI(self, s):   #run 所有数据已经处理完毕的接口函数
        # print(self.data)
        if self.paraType=="params":
            rsp=s.request(method=self.method,url=config.apiHost+self.url,params=self.data,verify=False)
        elif self.paraType=="data":
            rsp = s.request(method=self.method, url=config.apiHost + self.url, data=self.data,verify=False)
        elif self.paraType=="json":
            rsp = s.request(method=self.method, url=config.apiHost + self.url, json=self.data,verify=False)
        elif  self.paraType=="files":
            rsp = s.request(method=self.method, url=config.apiHost + self.url, files=self.data,verify=False)
        else:
            rsp = s.request(method=self.method, url=config.apiHost + self.url)
        return rsp

    #处理case['data']字符串的依赖变量，1.其他接口response取值
    def getReferPara(self,s,case,referAPIlist):    #去跑依赖的接口，返回的值replace data里的值
        # totalCaseNumber=caseG.getCaseNumbersById()  #所有的case对象caseG
        # print("监控参数列表")
        # print(referAPIlist)
        for i in referAPIlist:  #["config.12.id","config,13.entity"]
            api=i.split(".")
            caseId=int(api[1])
            # print("caseId是%d"%caseId)
            rspCatch=api[2]
            caseReferi=caseG.getTestCaseById(caseId,totalCaseNumber)
            rsptext=apiCase(caseReferi).runCase(s,caseReferi).text
            # print(rsptext)
            # print(rspCatch)
            para=random.choice(re.compile(r'"%s":(.*?)[,}]'%rspCatch).findall(rsptext))
            para=para.replace('"','')  #一旦变量不是字符串类型，例如是整形，是没有引号的，就没有办法获得了
            case['data']=case['data'].replace(i,'"'+para+'"')
        return case   #已经处理好了case[data]里的参数

    #处理url中的依赖变量
    def getUrlReferPara(self,s,case,referAPIlist):    #去跑依赖的接口，返回的值replace data里的值
        # totalCaseNumber=caseG.getCaseNumbersById()  #所有的case对象caseG
        # print("监控参数列表")
        # print(referAPIlist)
        for i in referAPIlist:  #["config.12.id","config,13.entity"]
            api=i.split(".")
            caseId=int(api[1])
            # print("caseId是%d"%caseId)
            rspCatch=api[2]
            caseReferi=caseG.getTestCaseById(caseId,totalCaseNumber)
            rsptext=apiCase(caseReferi).runCase(s,caseReferi).text
            # print(rsptext)
            # print(rspCatch)
            para=random.choice(re.compile(r'"%s":(.*?)[,}]'%rspCatch).findall(rsptext))
            para = para.replace('"', '')  # 一旦变量不是字符串类型，例如是整形，是没有引号的，就没有办法获得了
            case['url']=case['url'].replace(i,para)
        return case   #已经处理好了case[data]里的参数

    # 处理case['data']字符串的依赖变量，1.自生成函数
    def getReferMethod(self, s, case,referCommon):  # 去跑依赖的接口，返回的值replace data里的值
        for i in referCommon:  # ['common.people.id']
            common1 = i.split('.')  # ['common','people','id']
            className = common1[1]  # "people"
            classAttribute = common1[2]  # "id"
            classObj = self.classRefer[className]  # classRefer['people']=people()  获得一个类实例
            classAttributeDic = common.getClassAttributeKeyValueDict(classObj)  # 把类实例的属性改成字典
            para = classAttributeDic[classAttribute]  # 字典['id']
            case['data']=case['data'].replace(i, '"' + para + '"')
        return case  # 已经处理好了case[data]里的参数

    #处理case['data']字符串的依赖变量，1.file变量
    # 注意，在evel变量之前需要准备相应的变量
    # 也就是读取字符串，打开文件的过程
    def getReferFile(self,s,case,fileList):  #fileList ['file_importPersonsTemplet50_xlsx', 'file_custome_json_zip']
        for i in range(len(fileList)):
            file=config.testFilesPath+"\\"+fileList[i][fileList[i].find('_') + 1:][::-1].replace("_",".",1)[::-1]  #避开文件里的下划线
            self.fileObj.append(open(file,"rb"))
            case['data']=case['data'].replace(fileList[i],"self.fileObj[%d]"%i)
        return case

    #把测试结果回写到excel中,包含断言判断与回写
    def writeRunningResult(self, caseId, rsp):
        #把测试中的response解析后写入excel表格
        row = caseG.getTestCaseRowById(caseId,totalCaseNumber)
        resultList=[rsp.status_code,rsp.json().get('message'),rsp.text]
        if not resultList[1]:
            resultList[1]="no_msg"
        caseG.writeRow(caseG.sheet,resultList,row,12)
        #获取断言结果，判断测试是否通过，回写结果
        if rsp.text.find(self.assertExpected)>=0:
            result="pass"
        else:
            result='fail'
        caseG.writeCell(caseG.sheet,row,15,result)

    #跟runAPI的区别， runAPI所有数据已经ready，这个函数包括数据处理
    def runCase(self,s,case):  #这里的case字典， data值是字符串
        # 会导致初始化带这个case,run的时候还要带这个case,初始化的时候没有对其处理
        #先从caseData里提取三个列表
        if case['data']:   #当data = None时，无需处理
            referAll=caseG.getParaRefer(case)
            if referAll[0]:
                case = self.getReferPara(s,case,referAll[0])
                # print(case['data'])
            if referAll[1]:
                case = self.getReferMethod(s,case,referAll[1])
                # print(case['data'])
            if referAll[2]:
                case = self.getReferFile(s,case,referAll[2])
                # print(case['data'])
            # print(case['data'])
            case['data']=eval(case['data'])   #把case['data']转化字典
            # print(case['data'])
        #处理URL中的依赖
        urlrefer = caseG.getUrlParaRefer(case)  #如果有url的依赖
        if urlrefer:
            case = self.getUrlReferPara(s,case,urlrefer)
        #数据处理完毕，执行case
        # print("测试的url %s"%case['url'])
        rsp=apiCase(case).runAPI(s)
        #关闭case过程中打开的file文件
        if self.fileObj:
            for i in self.fileObj:
                i.close()
        self.writeRunningResult(self.id, rsp)   #把结果写到excel中去
        return rsp

#跑多个case，自动生成结果
class apiCaseList():

    s = session()
    #跑登录接口，保证有cookie
    rsp = s.request("get", url=config.apiHost + '/api/account/login', params={"password":"2580"}, verify=False)

    def runCaseList(self,caselist):
        for i in caselist:
            print("start-----------------------------------------")
            print(i['name'])
            # print(i)
            # 注意：以下两个步骤就可以跑一条case
            c1 = apiCase(i)
            rsp = c1.runCase(self.s, i)
            print("测试结果如下")
            print(rsp.json())
            print()

    # 1、跑所有的case
    def runAlltestCase(self):
        caseList = caseG.getTestCaseList(range(2, totalCaseNumber + 2))  # 按照row去跑case
        self.runCaseList(caseList)
        caseG.save()
        caseG.closeFile()
        print("测试结果文件：%s"%resultFile)

    # 2、按模块跑case
    def runCaseByModule(self,module):
        rowList = caseG.getApiTestCasesIdByFilter(totalCaseNumber,2,module)  # 按照row去跑case
        caseList = caseG.getTestCaseList(rowList)
        self.runCaseList(caseList)
        caseG.save()
        caseG.closeFile()
        print("测试结果文件：%s" % resultFile)

if __name__=="__main__":
    # apiCaseList().runCaseByModule("工作台")
    apiCaseList().runAlltestCase()
