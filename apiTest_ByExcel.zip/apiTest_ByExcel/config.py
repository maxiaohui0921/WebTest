#测试excel文件
casePath=r"D:\01.Projects\apiTest_ByExcel\test_case\API_template.xlsx"
imageFolderPath=r"D:\01.Projects\beeboxes\test_data\照片"
testFilesPath=r"D:\01.Projects\beeboxes\test_data"

#测试结果目录
testResultPath=r"D:\01.Projects\apiTest_ByExcel\test_result"

#测试接口的Host
apiHost="http://192.168.27.85:8080"
